package com.wuzj.service;

import com.wuzj.entity.UserLog;

/**
 * @author wuzj
 * @date 2023/8/29
 */
public interface UserLogService{

    boolean save(UserLog userLog);
}
